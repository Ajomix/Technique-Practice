
_start(){
	foo();
}