#include <stdio.h>


static inline void hello(){
        puts("Hello");
}
int main(){
        hello();
        return 0;
}
 