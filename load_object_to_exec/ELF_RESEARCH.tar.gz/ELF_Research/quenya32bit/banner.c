#include "elfmod.h"

void banner(void)
{
	printf("\nWelcome to Quenya v0.1 -- the ELF modification and analysis tool\n"
	       "Designed and maintained by Ryan O. <ryan@bitlackeys.com>\n\n");
	printf("Type 'help' for a list of commands\n\n");
}

