#include <stdio.h>

int main(void)
{
	for(;;)
	{
		printf("I'm an angel!\n");
		sleep(2);
	}
}

