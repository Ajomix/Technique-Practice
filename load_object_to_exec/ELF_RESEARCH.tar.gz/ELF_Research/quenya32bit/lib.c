void check(void)
{
	printf("Fuck you all\n");
	exit(0);
}

