__asm__("pushl $0xff000000\n"
	"ret");

