#include "elfmod.h"

/*
 * Control flow feature
 */

int run_control_flow(Elfmem32_t *elf)
{
	











}


